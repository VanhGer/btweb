console.log('Dòng đầu tiên');

setTimeout(function () {
    console.log('Dòng số 2');
}, 2000);

console.log('Dòng số 3');